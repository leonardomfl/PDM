package br.ucsal.av1.ui;

import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import br.ucsal.av1.R;

public class CadastrarEventoActivity extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_cadastrar_evento);
        setTitle("Cadastrar Evento");
    }

}