package br.ucsal.av1.ui;

import android.os.Bundle;
import android.support.annotation.Nullable;
import android.support.v7.app.AppCompatActivity;
import android.widget.ArrayAdapter;
import android.widget.ListView;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.Collections;
import java.util.List;
import br.ucsal.av1.R;

public class EventosCadastradosActivity extends AppCompatActivity {

    @Override
    protected void onCreate(@Nullable Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_eventos_cadastrados);
        setTitle("Eventos Cadastrados");
        List<String> list = new ArrayList<>(
                Arrays.asList("Evento #4", "Evento #2", "Evento #5", "Evento #3", "Evento #1"));
        Collections.sort(list);
        ListView listView = findViewById(R.id.activity_eventos_cadastrados_lv);
        listView.setAdapter(new ArrayAdapter<>(
                this,
                android.R.layout.simple_list_item_1,
                list));
    }

}
