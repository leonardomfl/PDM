package br.ucsal.av1;

import android.os.Build;
import android.support.annotation.RequiresApi;

import br.ucsal.av1.dao.EventoDAO;
import br.ucsal.av1.model.Evento;

import static br.ucsal.av1.dao.EventoDAO.ultimoIdGerado;

public class EventosApplication extends android.app.Application {

    @RequiresApi(api = Build.VERSION_CODES.N)
    @Override
    public void onCreate() {
        super.onCreate();
        criarEventos();
    }

    @RequiresApi(api = Build.VERSION_CODES.N)
    private void criarEventos() {
        EventoDAO eventoDAO = new EventoDAO();
        eventoDAO.inserir(new Evento(ultimoIdGerado, "E#" + ultimoIdGerado, "25/10/2000", "50"));
        eventoDAO.inserir(new Evento(ultimoIdGerado, "E#" + ultimoIdGerado, "15/05/1995", "25"));
        eventoDAO.inserir(new Evento(ultimoIdGerado, "E#" + ultimoIdGerado, "05/01/1990", "5"));
    }

}