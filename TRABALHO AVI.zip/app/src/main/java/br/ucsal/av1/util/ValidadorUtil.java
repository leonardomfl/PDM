package br.ucsal.av1.util;

import android.os.Build;
import android.support.annotation.RequiresApi;
import android.util.Log;

import java.time.LocalDate;
import java.time.LocalDateTime;
import java.time.format.DateTimeFormatter;
import java.time.format.DateTimeParseException;
import java.time.format.ResolverStyle;

@RequiresApi(api = Build.VERSION_CODES.O)
public class ValidadorUtil {

    private static DateTimeFormatter DATE_TIME_FORMATTER = DateTimeFormatter.ofPattern("dd/MM/uuuu");

    @RequiresApi(api = Build.VERSION_CODES.O)
    public static boolean ehUmaDataValida(String data) {
        try {
            LocalDate.parse(data, DATE_TIME_FORMATTER.withResolverStyle(ResolverStyle.STRICT));
        } catch (DateTimeParseException dtpe) {
            Log.w("DATA INVÁLIDA", "A data informada é inválida");
            return false;
        }
        return true;
    }

}