package br.ucsal.av1.ui;

import android.content.Intent;
import android.os.Build;
import android.support.annotation.RequiresApi;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;

import br.ucsal.av1.R;
import br.ucsal.av1.dao.EventoDAO;
import br.ucsal.av1.model.Evento;
import br.ucsal.av1.util.MaskUtil;

public class CadastrarEventoActivity extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_cadastrar_evento);
        setTitle("Cadastrar Evento");
        final EditText campoNome = findViewById(R.id.activity_cadastrar_evento_edit_text_nome);
        final EditText campoData = findViewById(R.id.activity_cadastrar_evento_edit_text_data);
        campoData.addTextChangedListener(MaskUtil.insert(MaskUtil.DATA_MASK, campoData));
        final EditText campoValorIngresso = findViewById(R.id.activity_cadastrar_evento_edit_text_valor_ingresso);
        Button botaoSalvar = findViewById(R.id.activity_cadastrar_evento_button_salvar);
        botaoSalvar.setOnClickListener(new View.OnClickListener() {
            @RequiresApi(api = Build.VERSION_CODES.N)
            @Override
            public void onClick(View v) {
                String nome = campoNome.getText().toString();
                String data = campoData.getText().toString();
                String valorIngresso = campoValorIngresso.getText().toString();
                Evento evento = new Evento(nome, data, valorIngresso);
                EventoDAO dao = new EventoDAO();
                boolean inseriu = dao.inserir(evento);
                if (inseriu) {
                    Toast.makeText(CadastrarEventoActivity.this, "O evento foi salvo com sucesso!", Toast.LENGTH_LONG).show();
                } else {
                    Toast.makeText(CadastrarEventoActivity.this, "O evento já foi cadastrado!", Toast.LENGTH_LONG).show();
                }
                startActivity(new Intent(CadastrarEventoActivity.this, EventosCadastradosActivity.class));
            }
        });
    }

}