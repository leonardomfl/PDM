package br.ucsal.av1.ui;

import android.os.Build;
import android.os.Bundle;
import android.support.annotation.RequiresApi;
import android.support.v7.app.AppCompatActivity;
import android.text.Editable;
import android.text.TextWatcher;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;
import br.ucsal.av1.R;
import br.ucsal.av1.dao.EventoDAO;
import br.ucsal.av1.model.Evento;
import br.ucsal.av1.util.GeradorUtil;
import br.ucsal.av1.util.ValidadorUtil;
import static br.ucsal.av1.ui.Constantes.TITULO_APPBAR_CADASTRAR_EVENTO;

public class CadastrarEventoActivity extends AppCompatActivity {

    private EditText campoNome;
    private EditText campoData;
    private EditText campoValorIngresso;
    private Button botaoSalvar;
    private Button botaoCancelar;
    private final Evento evento = new Evento();
    private final EventoDAO eventoDAO = new EventoDAO();
    private int qtdCamposValidos;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_cadastrar_evento);
        setTitle(TITULO_APPBAR_CADASTRAR_EVENTO);
        inicializarCampos();
        inicializarBotoes();
        configurarCampoNome();
        configurarCampoData();
        configurarCampoValorIngresso();
        configurarBotaoSalvar();
        configurarBotaoCancelar();
    }

    private void inicializarCampos() {
        campoNome = findViewById(R.id.activity_cadastrar_evento_edit_text_nome);
        campoData = findViewById(R.id.activity_cadastrar_evento_edit_text_data);
        campoData.addTextChangedListener(GeradorUtil.insert(GeradorUtil.DATA_MASK, campoData));
        campoValorIngresso = findViewById(R.id.activity_cadastrar_evento_edit_text_valor_ingresso);
    }

    private void inicializarBotoes() {
        botaoSalvar = findViewById(R.id.activity_cadastrar_evento_button_salvar);
        botaoCancelar = findViewById(R.id.activity_cadastrar_evento_button_cancelar);
    }

    private void configurarCampoNome() {
        campoNome.addTextChangedListener(new TextWatcher() {
            @Override
            public void beforeTextChanged(CharSequence charSequence, int i, int i1, int i2) {
            }

            @Override
            public void onTextChanged(CharSequence charSequence, int i, int i1, int i2) {
            }

            @Override
            public void afterTextChanged(Editable editable) {
                if (editable.length() < 3) {
                    campoNome.setError("O nome informado é inválido!");
                } else {
                    campoNome.setError(null);
                    qtdCamposValidos++;
                }
            }
        });
    }

    private void configurarCampoData() {
        campoData.addTextChangedListener(new TextWatcher() {
            @Override
            public void beforeTextChanged(CharSequence charSequence, int i, int i1, int i2) {
            }

            @Override
            public void onTextChanged(CharSequence charSequence, int i, int i1, int i2) {
            }

            @RequiresApi(api = Build.VERSION_CODES.O)
            @Override
            public void afterTextChanged(Editable editable) {
                if (editable.toString().length() < 10) {
                    campoData.setError("A data informada é inválida!");
                } else {
                    if (ValidadorUtil.ehUmaDataValida(editable.toString())) {
                        campoData.setError(null);
                        qtdCamposValidos++;
                    } else {
                        campoData.setError("A data informada é inválida!");
                    }
                }
            }
        });
    }

    private void configurarCampoValorIngresso() {
        campoValorIngresso.addTextChangedListener(new TextWatcher() {
            @Override
            public void beforeTextChanged(CharSequence charSequence, int i, int i1, int i2) {
            }

            @Override
            public void onTextChanged(CharSequence charSequence, int i, int i1, int i2) {
            }

            @Override
            public void afterTextChanged(Editable editable) {
                if (editable.toString().equals("") || Integer.parseInt(editable.toString()) < 1) {
                    campoValorIngresso.setError("O valor do ingresso informado é inválido!");
                } else {
                    campoValorIngresso.setError(null);
                    qtdCamposValidos++;
                }
            }
        });
    }

    private void configurarBotaoSalvar() {
        botaoSalvar.setOnClickListener(new View.OnClickListener() {
            @RequiresApi(api = Build.VERSION_CODES.N)
            @Override
            public void onClick(View v) {
                finalizarCadastro();
            }
        });
    }

    @RequiresApi(api = Build.VERSION_CODES.N)
    private void finalizarCadastro() {
        if (qtdCamposValidos >= 3) {
            receberDadosInformadosCampos();
            boolean eventoFoiCadastrado = eventoDAO.inserir(evento);
            if (eventoFoiCadastrado) {
                Toast.makeText(CadastrarEventoActivity.this, "O evento foi cadastrado com sucesso!", Toast.LENGTH_LONG).show();
            } else {
                Toast.makeText(CadastrarEventoActivity.this, "Os dados informados já foram cadastrados em outro evento!", Toast.LENGTH_LONG).show();
            }
            finish();
        } else {
            if (campoNome.getText().toString().equals("") && campoData.getText().toString().equals("") && campoValorIngresso.getText().toString().equals("")) {
                Toast.makeText(CadastrarEventoActivity.this, "Para realizar o cadastro do evento é necessário que todos os campos estejam preenchidos!", Toast.LENGTH_LONG).show();
            } else {
                Toast.makeText(CadastrarEventoActivity.this, "Para realizar o cadastro do evento é necessário que todos os campos estejam validados!", Toast.LENGTH_LONG).show();
            }
        }
    }

    private void configurarBotaoCancelar() {
        botaoCancelar.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Toast.makeText(CadastrarEventoActivity.this, "O cadastro do evento foi cancelado com sucesso!", Toast.LENGTH_LONG).show();
                finish();
            }
        });
    }

    private void receberDadosInformadosCampos() {
        String nome = campoNome.getText().toString();
        String data = campoData.getText().toString();
        String valorIngresso = campoValorIngresso.getText().toString();
        evento.setNome(nome);
        evento.setData(data);
        evento.setValorIngresso(valorIngresso);
    }

}