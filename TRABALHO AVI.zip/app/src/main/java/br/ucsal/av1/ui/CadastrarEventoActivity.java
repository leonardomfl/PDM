package br.ucsal.av1.ui;

import android.content.Intent;
import android.os.Build;
import android.support.annotation.NonNull;
import android.support.annotation.RequiresApi;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;

import java.text.ParseException;
import java.text.SimpleDateFormat;

import br.ucsal.av1.R;
import br.ucsal.av1.dao.EventoDAO;
import br.ucsal.av1.model.Evento;
import br.ucsal.av1.util.MaskUtil;

public class CadastrarEventoActivity extends AppCompatActivity {

    public static final String TITULO_APPBAR = "Cadastrar Evento";
    private EditText campoNome;
    private EditText campoData;
    private EditText campoValorIngresso;
    private final static EventoDAO eventoDAO = new EventoDAO();

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_cadastrar_evento);
        setTitle(TITULO_APPBAR);
        inicializarCampos();
        configurarBotaoSalvar();
        configurarBotaoCancelar();
    }

    private void inicializarCampos() {
        campoNome = findViewById(R.id.activity_cadastrar_evento_edit_text_nome);
        campoData = findViewById(R.id.activity_cadastrar_evento_edit_text_data);
        campoData.addTextChangedListener(MaskUtil.insert(MaskUtil.DATA_MASK, campoData));
        campoValorIngresso = findViewById(R.id.activity_cadastrar_evento_edit_text_valor_ingresso);
    }

    private void configurarBotaoSalvar() {
        final Button botaoSalvar = findViewById(R.id.activity_cadastrar_evento_button_salvar);
        botaoSalvar.setEnabled(false);
        configurarCampoData(botaoSalvar);
        botaoSalvar.setOnClickListener(new View.OnClickListener() {
            @RequiresApi(api = Build.VERSION_CODES.N)
            @Override
            public void onClick(View v) {
                Evento evento = criar();
                salvar(evento);
            }
        });
    }

    private void configurarBotaoCancelar() {
        final Button botaoCancelar = findViewById(R.id.activity_cadastrar_evento_button_cancelar);
        botaoCancelar.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Toast.makeText(CadastrarEventoActivity.this, "O cadastro do evento foi cancelado com sucesso!", Toast.LENGTH_SHORT).show();
                startActivity(new Intent(CadastrarEventoActivity.this, EventosCadastradosActivity.class));
            }
        });
    }

    private void configurarCampoData(final Button botaoSalvar) {
        campoData.setOnFocusChangeListener(new View.OnFocusChangeListener() {
            @Override
            public void onFocusChange(View v, boolean hasFocus) {
                if (!hasFocus) {
                    String data = campoData.getText().toString();
                    try {
                        SimpleDateFormat simpleDateFormat = new SimpleDateFormat("dd/MM/yyyy");
                        simpleDateFormat.setLenient(false);
                        data = simpleDateFormat.format(simpleDateFormat.parse(data));
                        botaoSalvar.setEnabled(true);
                        Toast.makeText(CadastrarEventoActivity.this, "A data informada é válida!", Toast.LENGTH_SHORT).show();
                    } catch (ParseException e) {
                        botaoSalvar.setEnabled(false);
                        Toast.makeText(CadastrarEventoActivity.this, "Favor informar uma data válida para realizar o cadastro!", Toast.LENGTH_SHORT).show();
                    }
                }
            }
        });
    }

    @NonNull
    private Evento criar() {
        String nome = campoNome.getText().toString();
        String data = campoData.getText().toString();
        String valorIngresso = campoValorIngresso.getText().toString();
        return new Evento(nome, data, valorIngresso);
    }

    @RequiresApi(api = Build.VERSION_CODES.N)
    private void salvar(Evento evento) {
        boolean inseriu = eventoDAO.inserir(evento);
        if (inseriu) {
            Toast.makeText(CadastrarEventoActivity.this, "O evento foi salvo com sucesso!", Toast.LENGTH_SHORT).show();
        } else {
            Toast.makeText(CadastrarEventoActivity.this, "O evento já foi cadastrado!", Toast.LENGTH_SHORT).show();
        }
        finish();
    }

}