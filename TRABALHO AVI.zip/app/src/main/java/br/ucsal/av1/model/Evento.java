package br.ucsal.av1.model;

public class Evento {

    private final String nome;
    private final String data;
    private final String valorIngresso;

    public Evento(String nome, String data, String valorIngresso) {
        this.nome = nome;
        this.data = data;
        this.valorIngresso = valorIngresso;
    }

    @Override
    public String toString() {
        return nome + "\n" + data + "\nR$ " + valorIngresso;
    }

}