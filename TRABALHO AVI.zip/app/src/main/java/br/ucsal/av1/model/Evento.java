package br.ucsal.av1.model;

import android.support.annotation.NonNull;
import android.widget.EditText;

import java.io.Serializable;

public class Evento implements Serializable {

    private String nome;
    private String data;
    private String valorIngresso;

    public Evento(String nome, String data, String valorIngresso) {
        this.nome = nome;
        this.data = data;
        this.valorIngresso = valorIngresso;
    }

    public String getNome() {
        return nome;
    }

    public void setNome(String nome) {
        this.nome = nome;
    }

    public String getData() {
        return data;
    }

    public void setData(String data) {
        this.data = data;
    }

    public String getValorIngresso() {
        return valorIngresso;
    }

    public void setValorIngresso(String valorIngresso) {
        this.valorIngresso = valorIngresso;
    }

    @NonNull
    @Override
    public String toString() {
        return nome + "\n" + data + "\nR$ " + valorIngresso;
    }

}