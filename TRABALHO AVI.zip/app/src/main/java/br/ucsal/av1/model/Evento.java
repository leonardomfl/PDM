package br.ucsal.av1.model;

import android.support.annotation.NonNull;
import android.widget.EditText;

public class Evento {

    private final String nome;
    private final String data;
    private final String valorIngresso;

    public Evento(String nome, String data, String valorIngresso) {
        this.nome = nome;
        this.data = data;
        this.valorIngresso = valorIngresso;
    }

    @NonNull
    @Override
    public String toString() {
        return nome + "\n" + data + "\nR$ " + valorIngresso;
    }

}