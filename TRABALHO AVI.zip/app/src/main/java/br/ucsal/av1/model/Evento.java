package br.ucsal.av1.model;

import android.support.annotation.NonNull;
import java.io.Serializable;
import static br.ucsal.av1.dao.EventoDAO.ultimoIdGerado;

public class Evento implements Serializable {

    private int id;
    private String nome;
    private String data;
    private String valorIngresso;

    public Evento() {
        id = ultimoIdGerado;
        nome = "";
        data = "";
        valorIngresso = "";
    }

    public Evento(int id, String nome, String data, String valorIngresso) {
        this.id = id;
        this.nome = nome;
        this.data = data;
        this.valorIngresso = valorIngresso;
    }

    public int getId() {
        return id;
    }

    public void setId(int id) {
        this.id = id;
    }

    public String getNome() {
        return nome;
    }

    public void setNome(String nome) {
        this.nome = nome;
    }

    public String getData() {
        return data;
    }

    public void setData(String data) {
        this.data = data;
    }

    public String getValorIngresso() {
        return valorIngresso;
    }

    public void setValorIngresso(String valorIngresso) {
        this.valorIngresso = valorIngresso;
    }

    @NonNull
    @Override
    public String toString() {
        return id + "\n" + nome + "\n" + data + "\nR$ " + valorIngresso;
    }

    public boolean temIdValido() {
        return id > 0;
    }

}