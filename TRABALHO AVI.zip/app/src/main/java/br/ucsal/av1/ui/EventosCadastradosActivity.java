package br.ucsal.av1.ui;

import android.content.Intent;
import android.os.Build;
import android.os.Bundle;
import android.support.annotation.Nullable;
import android.support.annotation.RequiresApi;
import android.support.design.widget.FloatingActionButton;
import android.support.v7.app.AppCompatActivity;
import android.util.Log;
import android.view.View;
import android.widget.AdapterView;
import android.widget.ArrayAdapter;
import android.widget.ListView;
import android.widget.Toast;

import java.util.List;

import br.ucsal.av1.R;
import br.ucsal.av1.dao.EventoDAO;
import br.ucsal.av1.model.Evento;

public class EventosCadastradosActivity extends AppCompatActivity {

    public static final String TITULO_APPBAR = "Eventos Cadastrados";
    private final static EventoDAO eventoDAO = new EventoDAO();

    @RequiresApi(api = Build.VERSION_CODES.N)
    @Override
    protected void onCreate(@Nullable Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_eventos_cadastrados);
        setTitle(TITULO_APPBAR);
        configurarFloatingActionButton();
        cadastrarEventosAutomaticamente();
    }

    private void configurarFloatingActionButton() {
        FloatingActionButton floatingActionButton = findViewById(R.id.activity_eventos_cadastrados_fab);
        floatingActionButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                abrirTelaCadastrarEvento();
            }
        });
    }

    private void abrirTelaCadastrarEvento() {
        startActivity(new Intent(this, CadastrarEventoActivity.class));
    }

    @RequiresApi(api = Build.VERSION_CODES.N)
    private void cadastrarEventosAutomaticamente() {
        Evento e1 = new Evento("#1", "26/03/2011", "123");
        Evento e2 = new Evento("#2", "14/07/2015", "456");
        Evento e3 = new Evento("#3", "02/11/2019", "789");
        if (eventoDAO.buscar(e1) && eventoDAO.buscar(e2) && eventoDAO.buscar(e3)) {
            eventoDAO.inserir(e1);
            eventoDAO.inserir(e2);
            eventoDAO.inserir(e3);
        }
    }

    @Override
    protected void onResume() {
        super.onResume();
        configurarListView();
    }

    private void configurarListView() {
        ListView listView = findViewById(R.id.activity_eventos_cadastrados_lv);
        final List<Evento> eventos = eventoDAO.retornarTodos();
        listView.setAdapter(new ArrayAdapter<>(
                this,
                android.R.layout.simple_list_item_1,
                eventos));
        listView.setOnItemClickListener(new AdapterView.OnItemClickListener() {
            @Override
            public void onItemClick(AdapterView<?> adapterView, View view, int posicao, long id) {
                Evento evento = eventos.get(posicao);
                Log.i("Evento", "Nome = " + evento.getNome() + " | Data = " + evento.getData() + " | Valor do Ingresso = " + evento.getValorIngresso());
                Intent intent = new Intent(EventosCadastradosActivity.this, CadastrarEventoActivity.class);
                intent.putExtra("evento", evento);
                startActivity(intent);
            }
        });
    }

}