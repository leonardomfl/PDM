package br.ucsal.av1.ui;

import android.content.Intent;
import android.os.Bundle;
import android.support.annotation.Nullable;
import android.support.design.widget.FloatingActionButton;
import android.support.v7.app.AppCompatActivity;
import android.view.View;
import android.widget.ArrayAdapter;
import android.widget.ListView;

import java.text.Collator;
import java.util.Collections;
import java.util.List;

import br.ucsal.av1.R;
import br.ucsal.av1.dao.EventoDAO;
import br.ucsal.av1.model.Evento;

public class EventosCadastradosActivity extends AppCompatActivity {

    @Override
    protected void onCreate(@Nullable Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_eventos_cadastrados);
        setTitle("Eventos Cadastrados");
        ListView listView = findViewById(R.id.activity_eventos_cadastrados_lv);
        FloatingActionButton floatingActionButton = findViewById(R.id.activity_eventos_cadastrados_fab);
        floatingActionButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                startActivity(new Intent(EventosCadastradosActivity.this, CadastrarEventoActivity.class));
            }
        });
        EventoDAO dao = new EventoDAO();
        listView.setAdapter(new ArrayAdapter<>(
                this,
                android.R.layout.simple_list_item_1,
                dao.retornarTodos()));
    }

}
