package br.ucsal.av1.ui;

import android.content.Intent;
import android.os.Bundle;
import android.support.annotation.Nullable;
import android.support.design.widget.FloatingActionButton;
import android.support.v7.app.AppCompatActivity;
import android.view.View;
import android.widget.ArrayAdapter;
import android.widget.ListView;

import br.ucsal.av1.R;
import br.ucsal.av1.dao.EventoDAO;

public class EventosCadastradosActivity extends AppCompatActivity {

    public static final String TITULO_APPBAR = "Eventos Cadastrados";
    private final static EventoDAO eventoDAO = new EventoDAO();

    @Override
    protected void onCreate(@Nullable Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_eventos_cadastrados);
        setTitle(TITULO_APPBAR);
        configurarFloatingActionButton();
    }

    private void configurarFloatingActionButton() {
        FloatingActionButton floatingActionButton = findViewById(R.id.activity_eventos_cadastrados_fab);
        floatingActionButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                abrirTelaCadastrarEvento();
            }
        });
    }

    private void abrirTelaCadastrarEvento() {
        startActivity(new Intent(this, CadastrarEventoActivity.class));
    }

    @Override
    protected void onResume() {
        super.onResume();
        configurarListView();
    }

    private void configurarListView() {
        ListView listView = findViewById(R.id.activity_eventos_cadastrados_lv);
        listView.setAdapter(new ArrayAdapter<>(
                this,
                android.R.layout.simple_list_item_1,
                eventoDAO.retornarTodos()));
    }

}
