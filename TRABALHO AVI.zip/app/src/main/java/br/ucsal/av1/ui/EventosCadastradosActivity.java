package br.ucsal.av1.ui;

import android.content.Intent;
import android.os.Build;
import android.os.Bundle;
import android.support.annotation.Nullable;
import android.support.annotation.RequiresApi;
import android.support.design.widget.FloatingActionButton;
import android.support.v7.app.AppCompatActivity;
import android.view.ContextMenu;
import android.view.MenuItem;
import android.view.View;
import android.widget.AdapterView;
import android.widget.Button;
import android.widget.ListView;
import android.widget.Toast;
import java.text.DecimalFormat;
import java.util.List;
import br.ucsal.av1.R;
import br.ucsal.av1.dao.EventoDAO;
import br.ucsal.av1.model.Evento;
import br.ucsal.av1.util.adapter.EventosCadastradosAdapter;
import static br.ucsal.av1.dao.EventoDAO.ultimaPosicaoAtualizacao;
import static br.ucsal.av1.ui.Constantes.CHAVE_EVENTO;

public class EventosCadastradosActivity extends AppCompatActivity {

    public static final String TITULO_APPBAR = "Eventos Cadastrados";
    private final static EventoDAO eventoDAO = new EventoDAO();
    private EventosCadastradosAdapter adapter;

    @RequiresApi(api = Build.VERSION_CODES.N)
    @Override
    protected void onCreate(@Nullable Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_eventos_cadastrados);
        setTitle(TITULO_APPBAR);
        configurarButton();
        configurarFloatingActionButton();
        configurarListView();
    }

    @Override
    public void onCreateContextMenu(ContextMenu menu, View v, ContextMenu.ContextMenuInfo menuInfo) {
        super.onCreateContextMenu(menu, v, menuInfo);
        getMenuInflater()
                .inflate(R.menu.activity_list_view_menu, menu);
    }

    private void configurarButton() {
        Button Button = (Button) findViewById(R.id.btn_media_precos);
        configurarOnClickListenerButton(Button);
    }

    private void configurarOnClickListenerButton(Button Button) {
        Button.setOnClickListener(new View.OnClickListener() {
            public void onClick(View v) {
                Toast.makeText(EventosCadastradosActivity.this, "Média de Preços: R$" + new DecimalFormat("#.##").format(obterMediaPrecos()), Toast.LENGTH_LONG).show();
            }
        });
    }

    private double obterMediaPrecos() {
        List<Evento> eventos = eventoDAO.retornarTodos();
        double somaPrecos = 0;
        for (Evento evento : eventos) {
            somaPrecos += Integer.parseInt(evento.getValorIngresso());
        }
        return somaPrecos / eventos.size();
    }

    private void configurarFloatingActionButton() {
        FloatingActionButton floatingActionButton = findViewById(R.id.activity_eventos_cadastrados_fab);
        configurarOnClickListenerFloatingActionButton(floatingActionButton);
    }

    private void configurarOnClickListenerFloatingActionButton(FloatingActionButton floatingActionButton) {
        floatingActionButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                abrirTelaCadastrarEvento();
            }
        });
    }

    private void abrirTelaCadastrarEvento() {
        startActivity(new Intent(this, CadastrarEventoActivity.class));
    }

    @Override
    protected void onResume() {
        super.onResume();
        atualizarArrayAdapter();
    }

    private void atualizarArrayAdapter() {
        adapter.atualiza(eventoDAO.retornarTodos());
    }

    private void configurarListView() {
        ListView listView = findViewById(R.id.activity_eventos_cadastrados_lv);
        configurarAdapterListView(listView);
        configurarItemClickListenerListView(listView);
        registerForContextMenu(listView);
    }

    @RequiresApi(api = Build.VERSION_CODES.N)
    @Override
    public boolean onContextItemSelected(MenuItem item) {
        int itemId = item.getItemId();
        if (itemId == R.id.activity_lista_alunos_menu_remover) {
            AdapterView.AdapterContextMenuInfo menuInfo =
                    (AdapterView.AdapterContextMenuInfo) item.getMenuInfo();
            Evento eventoSelecionado = adapter.getItem(menuInfo.position);
            removerEvento(eventoSelecionado);
        }
        return super.onContextItemSelected(item);
    }

    @RequiresApi(api = Build.VERSION_CODES.N)
    private void removerEvento(Evento eventoSelecionado) {
        eventoDAO.remover(eventoSelecionado);
        Toast.makeText(EventosCadastradosActivity.this, "O evento foi removido com sucesso!", Toast.LENGTH_LONG).show();
        adapter.remove(eventoSelecionado);
    }

    private void configurarAdapterListView(ListView listView) {
        adapter = new EventosCadastradosAdapter(this);
        listView.setAdapter(adapter);
    }

    private void configurarItemClickListenerListView(ListView listView) {
        listView.setOnItemClickListener(new AdapterView.OnItemClickListener() {
            @Override
            public void onItemClick(AdapterView<?> adapterView, View view, int posicao, long id) {
                Evento evento = (Evento) adapterView.getItemAtPosition(posicao);
                ultimaPosicaoAtualizacao = posicao;
                abrirTelaAtualizarEvento(evento);
            }
        });
    }

    private void abrirTelaAtualizarEvento(Evento evento) {
        Intent intent = new Intent(EventosCadastradosActivity.this, AtualizarEventoActivity.class);
        intent.putExtra(CHAVE_EVENTO, evento);
        startActivity(intent);
    }

}