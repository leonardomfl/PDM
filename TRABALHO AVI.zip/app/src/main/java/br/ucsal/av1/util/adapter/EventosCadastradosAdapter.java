package br.ucsal.av1.util.adapter;

import android.content.Context;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.BaseAdapter;
import android.widget.TextView;
import java.util.ArrayList;
import java.util.List;
import br.ucsal.av1.R;
import br.ucsal.av1.model.Evento;

public class EventosCadastradosAdapter extends BaseAdapter {

    private final List<Evento> eventos = new ArrayList<>();
    private final Context context;

    public EventosCadastradosAdapter(Context context) {
        this.context = context;
    }

    @Override
    public int getCount() {
        return eventos.size();
    }

    @Override
    public Evento getItem(int position) {
        return eventos.get(position);
    }

    @Override
    public long getItemId(int position) {
        return eventos.get(position).getId();
    }

    @Override
    public View getView(int position, View view, ViewGroup viewGroup) {
        View viewObtida = criaView(viewGroup);
        Evento eventoObtido = eventos.get(position);
        vincularInformacoes(viewObtida, eventoObtido);
        return viewObtida;
    }

    private void vincularInformacoes(View view, Evento evento) {
        TextView nome = view.findViewById(R.id.item_evento_nome);
        nome.setText(evento.getNome());
        TextView data = view.findViewById(R.id.item_evento_data);
        data.setText(evento.getData());
        TextView valorIngresso = view.findViewById(R.id.item_evento_valorIngresso);
        valorIngresso.setText(evento.getValorIngresso());
    }

    private View criaView(ViewGroup viewGroup) {
        return LayoutInflater
                .from(context)
                .inflate(R.layout.item_evento, viewGroup, false);
    }

    public void atualiza(List<Evento> eventos) {
        this.eventos.clear();
        this.eventos.addAll(eventos);
        notifyDataSetChanged();
    }

    public void remove(Evento evento) {
        eventos.remove(evento);
        notifyDataSetChanged();
    }

}