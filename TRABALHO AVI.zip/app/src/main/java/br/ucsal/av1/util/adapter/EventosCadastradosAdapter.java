package br.ucsal.av1.util.adapter;

import android.content.Context;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.BaseAdapter;
import android.widget.TextView;

import java.util.ArrayList;
import java.util.List;

import br.ucsal.av1.R;
import br.ucsal.av1.model.Evento;

public class EventosCadastradosAdapter extends BaseAdapter {

    private final List<Evento> eventos = new ArrayList<>();
    private Context context;

    public EventosCadastradosAdapter(Context context) {
        this.context = context;
    }

    @Override
    public int getCount() {
        return eventos.size();
    }

    @Override
    public Evento getItem(int position) {
        return eventos.get(position);
    }

    @Override
    public long getItemId(int position) {
        return eventos.get(position).getId();
    }

    @Override
    public View getView(int position, View view, ViewGroup viewGroup) {
        View viewObtida = LayoutInflater
                .from(context)
                .inflate(R.layout.item_evento, viewGroup, false);
        Evento eventoObtido = eventos.get(position);
        TextView nome = viewObtida.findViewById(R.id.item_evento_nome);
        nome.setText(eventoObtido.getNome());
//        TextView id = viewObtida.findViewById(R.id.item_evento_id);
//        id.setText(eventoObtido.getId());
        TextView data = viewObtida.findViewById(R.id.item_evento_data);
        data.setText(eventoObtido.getData());
        TextView valorIngresso = viewObtida.findViewById(R.id.item_evento_valorIngresso);
        valorIngresso.setText(eventoObtido.getValorIngresso());
        return viewObtida;
    }

    public void clear() {
        eventos.clear();
    }

    public void addAll(List<Evento> eventos) {
        this.eventos.addAll(eventos);
    }

    public void remove(Evento evento) {
        eventos.remove(evento);
    }

}