package br.ucsal.av1.dao;

import android.os.Build;
import android.support.annotation.RequiresApi;
import java.util.ArrayList;
import java.util.List;
import br.ucsal.av1.model.Evento;

public class EventoDAO {

    private final static List<Evento> eventos = new ArrayList<>();
    private static int ultimoIdGerado = 1;

    @RequiresApi(api = Build.VERSION_CODES.N)
    public boolean inserir(Evento evento) {
        Evento eventoEncontrado = buscar(evento);
        if (eventoEncontrado == null) {
            evento.setId(ultimoIdGerado);
            eventos.add(evento);
            atualizarIds();
            return true;
        }
        return false;
    }

    private void atualizarIds() {
        ultimoIdGerado++;
    }

    /* CORRIGIR A POSSIBILIDADE DE ATUALIZAR OS DADOS DE UM EVENTO, PARA O DE UM EVENTO QUE JÁ ESTÁ CADASTRADO. */
    @RequiresApi(api = Build.VERSION_CODES.N)
    public void atualizar(Evento evento) {
        Evento eventoEncontrado = buscar(evento);
        if ((eventoEncontrado.getNome() != evento.getNome()) || (eventoEncontrado.getData() != evento.getData()) || (eventoEncontrado.getValorIngresso() != evento.getValorIngresso())) {
            int indice = eventos.indexOf(eventoEncontrado);
            eventos.set(indice, evento);
        }
    }

    @RequiresApi(api = Build.VERSION_CODES.N)
    public Evento buscar(Evento evento) {
        for (Evento auxiliar : eventos) {
            if (auxiliar.getId() == evento.getId()) {
                return auxiliar;
            }
        }
        return null;
    }

    public List<Evento> retornarTodos() {
        return new ArrayList<>(eventos);
    }

    public boolean existemEventosDuplicados(Evento evento) {
        for (Evento auxiliar : eventos) {
            if ((auxiliar.getNome() == evento.getNome()) && (auxiliar.getData() == evento.getData()) && (auxiliar.getValorIngresso() == evento.getValorIngresso())) {
                return true;
            }
        }
        return false;
    }

}