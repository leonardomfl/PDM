package br.ucsal.av1.dao;

import android.os.Build;
import android.support.annotation.RequiresApi;

import java.util.ArrayList;
import java.util.List;

import br.ucsal.av1.model.Evento;

public class EventoDAO {

    private static List<Evento> eventos = new ArrayList<>();
    public static int ultimoIdGerado = 1, ultimaPosicaoAtualizacao;

    @RequiresApi(api = Build.VERSION_CODES.N)
    public boolean inserir(Evento evento) {
        boolean eventoEstaDuplicado = buscar(evento);
        if ((eventos.isEmpty() || !eventoEstaDuplicado)) {
            evento.setId(ultimoIdGerado);
            eventos.add(evento);
            atualizarIds();
            return true;
        }
        return false;
    }

    private void atualizarIds() {
        ultimoIdGerado++;
    }

    @RequiresApi(api = Build.VERSION_CODES.N)
    public boolean atualizar(Evento evento) {
        boolean eventoFoiEncontrado = buscar(evento.getId());
        boolean eventoEstaDuplicado = buscar(evento);
        if (eventoFoiEncontrado && !eventoEstaDuplicado) {
            eventos.set(ultimaPosicaoAtualizacao, evento);
            return true;
        }
        return false;
    }

    @RequiresApi(api = Build.VERSION_CODES.N)
    private boolean buscar(int id) {
        if (!eventos.isEmpty()) {
            for (Evento evento : eventos) {
                if (evento.getId() == id) {
                    return true;
                }
            }
        }
        return false;
    }

    @RequiresApi(api = Build.VERSION_CODES.N)
    private boolean buscar(Evento e1) {
        if (!eventos.isEmpty()) {
            for (Evento e2 : eventos) {
                if (e2.getNome().equals(e1.getNome()) && e2.getData().equals(e1.getData()) && e2.getValorIngresso().equals(e1.getValorIngresso())) {
                    return true;
                }
            }
        }
        return false;
    }

    @RequiresApi(api = Build.VERSION_CODES.N)
    public void remover(Evento evento) {
        boolean eventoFoiEncontrado = buscar(evento);
        if (eventoFoiEncontrado != false) {
            eventos.remove(evento);
        }
    }

    public List<Evento> retornarTodos() {
        return new ArrayList<>(eventos);
    }

}