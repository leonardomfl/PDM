package br.ucsal.av1.dao;

import android.os.Build;
import android.support.annotation.RequiresApi;
import java.util.ArrayList;
import java.util.List;
import br.ucsal.av1.model.Evento;

public class EventoDAO {

    private final static List<Evento> eventos = new ArrayList<>();

    @RequiresApi(api = Build.VERSION_CODES.N)
    public boolean inserir(Evento evento) {
        if (!eventos.contains(evento)) {
            eventos.add(evento);
            return true;
        }
        return false;
    }

    public List<Evento> retornarTodos() {
        return new ArrayList<>(eventos);
    }

}