package br.ucsal.av1.ui;

public interface Constantes {

    String CHAVE_EVENTO = "evento";
    String TITULO_APPBAR_CADASTRAR_EVENTO = "Cadastrar Evento";
    String TITULO_APPBAR_ATUALIZAR_EVENTO = "Atualizar Evento";

}