package br.ucsal.av1.ui;

public interface Constantes {

    String CHAVE_EVENTO = "evento";

}