package br.ucsal.av2.ui.activity;

interface Constantes {

    String CHAVE_ALUNO = "aluno";

}