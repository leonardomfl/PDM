package br.ucsal.av2.database;

import android.arch.persistence.room.Database;
import android.arch.persistence.room.Room;
import android.arch.persistence.room.RoomDatabase;
import android.arch.persistence.room.TypeConverters;
import android.content.Context;
import br.ucsal.av2.database.converter.Conversor;
import br.ucsal.av2.database.dao.AlunoDAO;
import br.ucsal.av2.model.Aluno;

import static br.ucsal.av2.database.AlunoMigrations.MIGRATIONS;

@Database(entities = {Aluno.class}, version = 1, exportSchema = false)
@TypeConverters({Conversor.class})
public abstract class AlunoDatabase extends RoomDatabase {

    private static final String BANCO_DADOS = "av2.db";

    public abstract AlunoDAO getRoomAlunoDAO();

    public static AlunoDatabase getInstance(Context context) {
        return Room
                .databaseBuilder(context, AlunoDatabase.class, BANCO_DADOS)
                .allowMainThreadQueries()
                .addMigrations(MIGRATIONS)
                .build();
    }

}