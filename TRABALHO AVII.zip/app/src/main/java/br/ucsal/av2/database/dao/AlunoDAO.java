package br.ucsal.av2.database.dao;

import android.arch.persistence.room.Dao;
import android.arch.persistence.room.Delete;
import android.arch.persistence.room.Insert;
import android.arch.persistence.room.Query;
import android.arch.persistence.room.Update;
import java.util.List;
import br.ucsal.av2.model.Aluno;

@Dao
public interface AlunoDAO {

    @Insert
    void inserir(Aluno aluno);

    @Query("SELECT * FROM aluno")
    List<Aluno> retornarTodos();

    @Delete
    void deletar(Aluno aluno);

    @Update
    void atualizar(Aluno aluno);

}