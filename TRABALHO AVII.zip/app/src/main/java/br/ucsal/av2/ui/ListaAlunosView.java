package br.ucsal.av2.ui;

import android.app.AlertDialog;
import android.content.Context;
import android.view.MenuItem;
import android.widget.AdapterView;
import android.widget.ListView;
import br.ucsal.av2.database.AlunoDatabase;
import br.ucsal.av2.database.dao.AlunoDAO;
import br.ucsal.av2.model.Aluno;
import br.ucsal.av2.ui.adapter.ListaAlunosAdapter;

public class ListaAlunosView {

    private final ListaAlunosAdapter adapter;
    private final AlunoDAO dao;
    private final Context context;

    public ListaAlunosView(Context context) {
        this.context = context;
        this.adapter = new ListaAlunosAdapter(this.context);
        dao = AlunoDatabase.getInstance(context)
                .getRoomAlunoDAO();
    }

    public void confirmarRemocao(final MenuItem item) {
        new AlertDialog
                .Builder(context)
                .setTitle("REMOVER O ALUNO")
                .setMessage("Tem certeza que deseja remover o aluno?")
                .setPositiveButton("SIM", (dialogInterface, i) -> {
                    AdapterView.AdapterContextMenuInfo menuInfo =
                            (AdapterView.AdapterContextMenuInfo) item.getMenuInfo();
                    Aluno alunoEscolhido = adapter.getItem(menuInfo.position);
                    remover(alunoEscolhido);
                })
                .setNegativeButton("NÃO", null)
                .show();
    }

    public void atualizarAlunos() {
        adapter.atualizar(dao.retornarTodos());
    }

    private void remover(Aluno aluno) {
        dao.deletar(aluno);
        adapter.remover(aluno);
    }

    public void configuraAdapter(ListView listaDeAlunos) {
        listaDeAlunos.setAdapter(adapter);
    }

}